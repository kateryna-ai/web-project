const express = require("express");
const mysql = require("mysql2/promise");
const bodyParser = require("body-parser");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const nodemailer = require("nodemailer");
const app = express();

app.use(express.json());
app.use(cookieParser());
app.use(cors({ origin: "http://127.0.0.1:5500" }));

app.use(bodyParser.urlencoded({ extended: true }));

const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "058r7sql3", 
  database: "test1_trips", port: 3307,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

const transporter = nodemailer.createTransport({
  service: "gmail",
  host: "smtp.gmail.com",
  port: 587,
  secure: false,
  auth: {
    user: "kateryna.sorokina1@nure.ua",
    pass: "plty syly lpkv uwox",
  },
});

const PORT = 3000;

app.get("/", (req, res) => {
  res.send("Сервер працює з базою даних!");
});

app.post("/register", async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).send("Усі поля обов'язкові!");
  }

  try {
    const checkUserSql = "SELECT * FROM users WHERE EmailUser = ?";
    const [existingUser] = await db.query(checkUserSql, [email]);

    if (existingUser.length > 0) {
      return res.status(400).send("Користувач з таким Еmail вже існує.");
    }

    const insertUserSql =
      "INSERT INTO users (NameUser, EmailUser, PasswordUser) VALUES (?, ?, ?)";

    await db.query(insertUserSql, [name, email, password]);

    await transporter.sendMail({
      from: "<maddison53@ethereal.email>",
      to: email,
      subject: "Welcome!",
      text: `Hello, ${name}! Welcome to our application!`,
      html: `<p>Hello, <b>${name}</b>! Welcome to our application!</p>`,
    });

    res.send("Реєстрація успішно завершена!");
  } catch (err) {
    console.error("Помилка виконання запиту:", err);
    res.status(500).send("Помилка реєстрації.");
  }
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).send("Усі поля обов'язкові!");
  }

  const query = "SELECT * FROM Users WHERE EmailUser = ? AND PasswordUser = ?";

  db.execute(query, [email, password])
    .then(([results]) => {
      if (results.length === 0) {
        return res.status(401).send("Неправильний Еmail чи пароль");
      }

      const user = results[0];
      const token = jwt.sign(
        { userId: user.IdUser, email: user.EmailUser },
        "secretKey",
        { expiresIn: "1h" }
      );

      res.send({
        message: "Логін успішний!",
        token,
        userId: user.IdUser,
        role: user.role,
      });
    })
    .catch((err) => {
      console.error("Помилка виконання запиту:", err);
      res.status(500).send("Помилка бази даних.");
    });
});

app.get("/tours", async (req, res) => {
  try {
    const [result] = await db.query("SELECT * FROM Tour");
    res.json(result);
  } catch (err) {
    console.error("Помилка при отриманні турів:", err);
    res.status(500).json({ error: "Помилка під час отримання турів" });
  }
});


// Роут для бронирования тура
app.post("/book", async (req, res) => {
  const { userId, tourId } = req.body;

  if (!userId || !tourId) {
    return res.status(400).json({ error: "Не вказано користувача або тур" });
  }

  try {
    const checkQuery = `
      SELECT * FROM Bookings WHERE IdTour = ? AND IdUser = ?
    `;
    const [existingBooking] = await db.query(checkQuery, [tourId, userId]);

    if (existingBooking.length > 0) {
      return res.status(400).json({ error: "Ви вже забронювали цей тур" });
    }

    const insertQuery = `
      INSERT INTO Bookings (IdTour, IdUser, BookingDate, TotalPrice)
      VALUES (?, ?, NOW(), (SELECT Price FROM Tour WHERE IdTour = ?))
    `;
    await db.query(insertQuery, [tourId, userId, tourId]);

    res.json({ message: "Бронювання успішно виконано!" });
  } catch (err) {
    console.error("Помилка при бронюванні:", err);
    res.status(500).json({ error: "Не вдалося забронювати тур" });
  }
});


app.get("/cities", async (req, res) => {
  try {
    const [rows] = await db.execute("SELECT * FROM Cities");

    if (!Array.isArray(rows)) {
      throw new Error("Query did not return an array");
    }
    res.json(rows); 
  } catch (err) {
    res.status(500).json({
      error: "Failed to fetch cities",
      message: err.message,
    });
  }
});

app.get("/guides", async (req, res) => {
  try {
    const [guides] = await db.execute(
      "SELECT IdGuide, FullName, Language, ExperienceYears FROM Guides"
    );

    res.json(guides);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch guides" });
  }
});

app.post("/add-attraction-and-tour", async (req, res) => {
  const { userId, attraction, tour } = req.body;

  if (!userId) {
    return res.status(400).json({ error: "Missing userId in request body" });
  }

  const connection = await db.getConnection();
  try {
    const [userResult] = await connection.execute(
      "SELECT role FROM Users WHERE IdUser = ?",
      [userId]
    );

    if (userResult.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    const userRole = userResult[0].role;

    if (userRole !== "admin") {
      return res.status(403).json({ error: "Access denied. Admins only." });
    }

    if (
      !attraction ||
      !attraction.name ||
      !attraction.cityId ||
      !tour ||
      !tour.name ||
      !tour.idGuide
    ) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    await connection.beginTransaction();

    const [attractionResult] = await connection.execute(
      "INSERT INTO Attractions (AttractionName, IdCity, Address, TicketPrice) VALUES (?, ?, ?, ?)",
      [
        attraction.name,
        attraction.cityId,
        attraction.address,
        attraction.ticketPrice,
      ]
    );

    const idAttraction = attractionResult.insertId;

    const [tourResult] = await connection.execute(
      "INSERT INTO Tour (NameTour, IdGuide, IdAttraction, DescriptionTour, Price, Place) VALUES (?, ?, ?, ?, ?, ?)",
      [
        tour.name,
        tour.idGuide,
        idAttraction,
        tour.description,
        tour.price,
        tour.place,
      ]
    );

    await connection.commit();

    res.json({
      message: "Attraction and Tour added successfully",
      attractionId: idAttraction,
      tourId: tourResult.insertId,
    });
  } catch (err) {
    await connection.rollback();
    console.error("Failed to add attraction and tour:", err);
    res.status(500).json({ error: "Failed to add attraction and tour" });
  } finally {
    connection.release();
  }
});

app.put("/update-attraction-and-tour", async (req, res) => {
  const {
    idAttraction, // ID аттракциона
    idTour, // ID тура
    attractionName,
    cityId,
    address,
    ticketPrice,
    nameTour,
    guideId,
    descriptionTour,
    tourPrice,
    place,
  } = req.body;

  // Проверяем наличие обязательных ID
  if (!idAttraction || !idTour) {
    return res
      .status(400)
      .json({ error: "Attraction ID and Tour ID are required" });
  }

  try {
    const connection = await db.getConnection();
    await connection.beginTransaction();

    // Динамическое обновление данных аттракциона
    const attractionUpdates = [];
    const attractionParams = [];
    if (attractionName) {
      attractionUpdates.push("AttractionName = ?");
      attractionParams.push(attractionName);
    }
    if (cityId) {
      attractionUpdates.push("IdCity = ?");
      attractionParams.push(cityId);
    }
    if (address) {
      attractionUpdates.push("Address = ?");
      attractionParams.push(address);
    }
    if (ticketPrice) {
      attractionUpdates.push("TicketPrice = ?");
      attractionParams.push(ticketPrice);
    }
    if (attractionUpdates.length > 0) {
      attractionParams.push(idAttraction);
      const attractionQuery = `
        UPDATE Attractions
        SET ${attractionUpdates.join(", ")}
        WHERE IdAttraction = ?
      `;
      await connection.execute(attractionQuery, attractionParams);
    }

    // Динамическое обновление данных тура
    const tourUpdates = [];
    const tourParams = [];
    if (nameTour) {
      tourUpdates.push("NameTour = ?");
      tourParams.push(nameTour);
    }
    if (guideId) {
      tourUpdates.push("IdGuide = ?");
      tourParams.push(guideId);
    }
    if (descriptionTour) {
      tourUpdates.push("DescriptionTour = ?");
      tourParams.push(descriptionTour);
    }
    if (tourPrice) {
      tourUpdates.push("Price = ?");
      tourParams.push(tourPrice);
    }
    if (place) {
      tourUpdates.push("Place = ?");
      tourParams.push(place);
    }
    if (tourUpdates.length > 0) {
      tourParams.push(idTour);
      const tourQuery = `
        UPDATE Tour
        SET ${tourUpdates.join(", ")}
        WHERE IdTour = ?
      `;
      await connection.execute(tourQuery, tourParams);
    }

    await connection.commit();
    res.json({ message: "Attraction and Tour updated successfully" });
  } catch (err) {
    console.error("Error updating attraction and tour:", err);
    res.status(500).json({ error: "Failed to update attraction and tour" });
  }
});

app.delete("/delete-attraction", async (req, res) => {
  const { idAttraction } = req.body;

  if (!idAttraction) {
    return res.status(400).json({ error: "Attraction ID is required" });
  }

  try {
    const checkQuery = "SELECT 1 FROM Attractions WHERE IdAttraction = ?";
    const [rows] = await db.execute(checkQuery, [idAttraction]);

    if (rows.length === 0) {
      return res.status(404).json({ error: "Attraction not found" });
    }

    const deleteQuery = "DELETE FROM Attractions WHERE IdAttraction = ?";
    await db.execute(deleteQuery, [idAttraction]);

    res.json({ message: "Attraction deleted successfully" });
  } catch (err) {
    console.error("Error deleting attraction:", err);
    res.status(500).json({ error: "Failed to delete attraction" });
  }
});

app.delete("/delete-tour", async (req, res) => {
  const { idTour } = req.body;

  if (!idTour) {
    return res.status(400).json({ error: "Tour ID is required" });
  }

  try {
    const checkQuery = "SELECT 1 FROM Tour WHERE IdTour = ?";
    const [rows] = await db.execute(checkQuery, [idTour]);

    if (rows.length === 0) {
      return res.status(404).json({ error: "Tour not found" });
    }

    const deleteQuery = "DELETE FROM Tour WHERE IdTour = ?";
    await db.execute(deleteQuery, [idTour]);

    res.json({ message: "Tour deleted successfully" });
  } catch (err) {
    console.error("Error deleting tour:", err);
    res.status(500).json({ error: "Failed to delete tour" });
  }
});

app.listen(PORT, () => {
  console.log(`Сервер запущен: http://localhost:${PORT}`);
});
